import { Component, OnInit } from "@angular/core";
import { Login } from "../model/login";
import { AuthService } from "../service/auth.service";
import { Router } from "@angular/router";
import { LoginService } from "../service/login.service";

@Component({
  selector: "app-login",
  templateUrl: "./login.component.html",
  styleUrls: ["./login.component.css"]
})
export class LoginComponent implements OnInit {
  login: Login = new Login();
  today: String;
  constructor(private loginServ: LoginService, private router: Router) {}
  onLoginSubmit() {
    console.log("Inside the Object");
    console.log(JSON.stringify(this.login));

    this.loginServ.logInUser(this.login).subscribe(data => {
      if (data.success) {
        console.log("Login Success");
        localStorage.setItem("jwtToken", data.token);
        localStorage.setItem("user", JSON.stringify(data.user));

        this.today = data.token;

        // this.router.navigate(["/login"]);
      } else {
        console.log("Login failure");
        // this.router.navigate(["/register"]);
      }
    });
    this.login = new Login();
  }

  ngOnInit() {}
}
