import { Injectable } from "@angular/core";
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Observable } from "rxjs/index";
import { Register } from "../model/register";
import { RegisterResponse } from "../response/register-response";

@Injectable({
  providedIn: "root"
})
export class AuthService {
  constructor(private http: HttpClient) {}
  // uri : /users/register
  // visiblity : public
  // accept register obejct
  // error specs

  registerUser(register: Register): Observable<RegisterResponse> {
    let headers = new HttpHeaders();
    headers.append("Content-Type", "application/json");

    return this.http.post<RegisterResponse>(
      "http://localhost:8080/users/register",
      register,
      { headers: headers }
    );
    //.map(res => res.json());
  }
}
