import { Injectable } from "@angular/core";
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Observable } from "rxjs/index";
import { LoginResponse } from "../response/login-response";
import { Login } from "../model/login";

@Injectable({
  providedIn: "root"
})
export class LoginService {
  constructor(private http: HttpClient) {}

  logInUser(login: Login): Observable<LoginResponse> {
    let headers = new HttpHeaders();
    headers.append("Content-Type", "application/json");

    return this.http.post<LoginResponse>(
      "http://localhost:8080/users/authenticate",
      login,
      { headers: headers }
    );
  }
}
