import { Injectable } from "@angular/core";
import { HttpInterceptor } from "@angular/common/http";
import { HttpRequest } from "@angular/common/http";
import { HttpHandler } from "@angular/common/http";
import { HttpEvent } from "@angular/common/http";
import { Observable } from "rxjs";

@Injectable()
export class TokenInterceptor implements HttpInterceptor {
  intercept(
    req: HttpRequest<any>,
    next: HttpHandler
  ): Observable<HttpEvent<any>> {
    let token = window.localStorage.getItem("jwtToken");
    console.log("From Interceptor" + token);
    if (token) {
      req = req.clone({
        setHeaders: {
          Authorization: "Bearer" + token
        }
      });
    }

    return next.handle(req);
    //  throw new Error("Method not implemented.");
  }
}
