import { Authguards } from './authguards';

describe('Authguards', () => {
  it('should create an instance', () => {
    expect(new Authguards()).toBeTruthy();
  });
});
