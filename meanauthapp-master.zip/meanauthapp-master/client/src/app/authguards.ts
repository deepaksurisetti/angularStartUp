import { Injectable } from "@angular/core";
import { HttpClient, HttpHeaders } from "@angular/common/http";

import { Observable } from "rxjs/index";
import { Router, CanActivate } from "@angular/router";
@Injectable({
  providedIn: "root"
})
export class Authguards implements CanActivate {
  canActivate(
    route: import("@angular/router").ActivatedRouteSnapshot,
    state: import("@angular/router").RouterStateSnapshot
  ):
    | boolean
    | import("@angular/router").UrlTree
    | Observable<boolean | import("@angular/router").UrlTree>
    | Promise<boolean | import("@angular/router").UrlTree> {
    if (window.localStorage.getItem("token")) {
      return true;
    } else {
      this.route.navigate(["/login"]);
      return false;
    }
  }
  constructor(private route: Router) {}
}
