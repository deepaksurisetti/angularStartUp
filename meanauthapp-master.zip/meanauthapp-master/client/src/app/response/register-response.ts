export class RegisterResponse {
  success: boolean;
  msg: String;
}
