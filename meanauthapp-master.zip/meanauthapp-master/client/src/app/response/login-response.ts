import { Register } from "../model/register";
import { User } from "../model/user";

export class LoginResponse {
  success: boolean;
  token: string;
  user: User;
}
