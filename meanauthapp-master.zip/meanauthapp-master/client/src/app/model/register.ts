export class Register {
  name: String;
  username: String;
  email: String;
  password: String;
}
