export class Login {
  // name: String;
  username: String;
  //email: String;
  password: String;
}
